import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http: HttpClient) { }

  data = {
    "email": "test@123",
    "password": 1234
  }


// getData()
//  {
// let tempData = this.http.get('https://reqres.in/api/users?page=2');

// console.log(tempData);
// return tempData;

//  }
}
