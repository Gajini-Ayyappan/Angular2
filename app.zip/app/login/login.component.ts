import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service'
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email;
  pass;
  activebtn = true;

  constructor(
    private service: ServiceService,
    private router: Router
     
  ) { 
       setTimeout(() =>{  
       this.activebtn = false;  
      }, 10000);
  }


  ngOnInit() {

  }

  onLogin() {
    if (this.email == this.service.data.email) {
      this.router.navigate(['home']);
    }
    else {
      alert("Please enter valid details");
      //console.log('Error')
    }

    // this.service.getData().subscribe((data1: any)=>(
    //   console.log(data1.data[0].email)
    // ));
  }

}
